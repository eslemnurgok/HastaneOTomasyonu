/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import javax.swing.JOptionPane;

/**
 *
 * @author Muzaffer
 */
public class Helper {

    public static void ShowMsg(String str) {
        String msg;

        msg = switch (str) {
            case "fill" ->
                "Lütfen tüm alanları doldurunuz...";
            case "fail" ->
                "Kullanıcı adı veya şifre yanlış...";
            case "success" ->
                "Giriş başarıyla yapıldı...";
            default ->
                str;
        };
        JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
    }

}
