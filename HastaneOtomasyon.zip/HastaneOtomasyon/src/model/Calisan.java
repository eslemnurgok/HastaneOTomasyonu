/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public class Calisan {

    private int Id;
    private int doktorId;
    private int poliklinikId;
    private String doktorName;
    private String poliklinikName;

    public Calisan() {
    }

    public Calisan(int doktorId, String doktorName) {
        this.doktorId = doktorId;
        this.doktorName = doktorName;
    }

    public Calisan(int Id, String doktorName, String poliklinikName) {
        this.Id = Id;
        this.doktorName = doktorName;
        this.poliklinikName = poliklinikName;
    }

    public Calisan(int doktorId, int poliklinikId, String doktorName, String poliklinikName) {
        this.doktorId = doktorId;
        this.poliklinikId = poliklinikId;
        this.doktorName = doktorName;
        this.poliklinikName = poliklinikName;
    }

    public int getDoktorId() {
        return doktorId;
    }

    public void setDoktorId(int doktorId) {
        this.doktorId = doktorId;
    }

    public int getPoliklinikId() {
        return poliklinikId;
    }

    public void setPoliklinikId(int poliklinikId) {
        this.poliklinikId = poliklinikId;
    }

    public String getDoktorName() {
        return doktorName;
    }

    public void setDoktorName(String doktorName) {
        this.doktorName = doktorName;
    }

    public String getPoliklinikName() {
        return poliklinikName;
    }

    public void setPoliklinikName(String poliklinikName) {
        this.poliklinikName = poliklinikName;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("Calisan.txt") + 1) + ",";
        } catch (IOException ex) {
            Logger.getLogger(Calisan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
