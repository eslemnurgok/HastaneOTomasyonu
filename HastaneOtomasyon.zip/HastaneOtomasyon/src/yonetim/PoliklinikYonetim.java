/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim;

import DAO.PoliklinikDAO;
import java.io.IOException;
import java.util.List;
import model.Poliklinik;

/**
 *
 * @author Muzaffer
 */
public class PoliklinikYonetim {

    private Poliklinik poliklinik;
    private List<Poliklinik> liste;
    private PoliklinikDAO userDatabase;

    public PoliklinikYonetim() {
    }

    public void deletePoliklinik(String Id) throws IOException {

        this.getUserDatabase().delete(Id);

    }

    public void create(String name) throws IOException {

        Poliklinik newPoliklinik = this.getPoliklinik();

        newPoliklinik.setName(name);

        this.getUserDatabase().addPoliklinik(newPoliklinik);

    }

    public Poliklinik getPoliklinik() {
        if (this.poliklinik == null) {
            poliklinik = new Poliklinik();
        }
        return poliklinik;
    }

    public void setPoliklinik(Poliklinik poliklinik) {
        this.poliklinik = poliklinik;
    }

    public List<Poliklinik> getListe() {
        return liste;
    }

    public void setListe(List<Poliklinik> liste) {
        this.liste = liste;
    }

    public PoliklinikDAO getUserDatabase() {
        if (userDatabase == null) {
            this.userDatabase = new PoliklinikDAO();
        }
        return userDatabase;
    }

    public void setUserDatabase(PoliklinikDAO userDatabase) {
        this.userDatabase = userDatabase;
    }

}
