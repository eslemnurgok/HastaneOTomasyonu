/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import GUI.DoktorGUI;
import GUI.GirisGUI;
import helper.Helper;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import model.Doktor;
import yonetim.DoktorYonetim;

/**
 *
 * @author Muzaffer
 */
public class DoktorGUI_action implements ActionListener {

    private Doktor doktor;
    private final DoktorGUI doktorGUI;
    private SimpleDateFormat sdf;
    private DoktorYonetim dy;

    public DoktorGUI_action(DoktorGUI doktorGUI) {
        this.doktorGUI = doktorGUI;
    }

    public DoktorGUI_action(Doktor doktor, DoktorGUI doktorGUI) {
        this.doktor = doktor;
        this.doktorGUI = doktorGUI;
    }

    public Doktor getDoktor() {
        return doktor;
    }

    public void setDoktor(Doktor doktor) {
        this.doktor = doktor;
    }

    public DoktorYonetim getDy() {
        if (dy == null) {
            this.dy = new DoktorYonetim();
        }
        return dy;
    }

    public void setDy(DoktorYonetim dy) {
        this.dy = dy;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == doktorGUI.getBtn_dateEkle()) {

            sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = "";

            try {
                date = sdf.format(doktorGUI.getDate_calismaSaatleri().getDate());
            } catch (Exception e2) {
            }

            if (date.length() == 0) {
                Helper.ShowMsg("Lütfen tarih seçiniz...");
            } else {

                String time = " " + doktorGUI.getCbox_time().getSelectedItem().toString();
                String selectDate = date + time;

                try {
                    getDy().addWhour(doktorGUI.getD().getId(), doktorGUI.getD().getName(), selectDate);
                    doktorGUI.updateWhourModel();
                    Helper.ShowMsg("Ekleme başarılı...");
                } catch (IOException ex) {
                    Logger.getLogger(DoktorGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else if (e.getSource() == doktorGUI.getBtn_dateSil()) {

            String Id = doktorGUI.getTxtfld_kullaniciId().getText();

            if (Id.length() == 0) {
                Helper.ShowMsg("fill");
            } else {

                try {
                    this.getDy().deleteWhour(Id);
                    doktorGUI.updateWhourModel();
                    doktorGUI.getTxtfld_kullaniciId().setText(null);
                    Helper.ShowMsg("Silme başarılı...");

                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(BashekimGUI_action.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }

            }

        } else if (e.getSource() == doktorGUI.getBtn_cikis()) {
            GirisGUI g = new GirisGUI();
            g.setVisible(true);
            doktorGUI.dispose();
        } else {

        }

    }
}
