/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import DAO.DoktorDAO;
import GUI.GirisGUI;
import GUI.HastaGUI;
import helper.Helper;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.table.DefaultTableModel;
import model.DoktorCalismaSaati;
import model.Hasta;
import yonetim.HastaYonetim;

/**
 *
 * @author Muzaffer
 */
public class HastaGUI_action implements ActionListener {

    private final HastaGUI h;
    private DefaultTableModel whourModel;
    private Object[] whourData;
    private HastaYonetim hy;
    private Hasta hasta;

    public HastaYonetim getHy() {
        if (hy == null) {
            this.hy = new HastaYonetim();
        }
        return hy;
    }

    public void setHy(HastaYonetim hy) {
        this.hy = hy;
    }

    public HastaGUI_action(HastaGUI h) {
        this.h = h;
    }

    public Hasta getHasta() {
        return hasta;
    }

    public void setHasta(Hasta hasta) {
        this.hasta = hasta;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == h.getBtn_doktorSec()) {

            int selectedRow = h.getTable_doktorList().getSelectedRow();
            if (selectedRow >= 0) {
                String value = h.getTable_doktorList().getModel().getValueAt(selectedRow, 0).toString();
                int Id = Integer.parseInt(value);

                whourModel = new DefaultTableModel();
                Object[] colWhourName = new Object[2];

                colWhourName[0] = "ID";

                colWhourName[1] = "Tarih ve Saat";

                whourModel.setColumnIdentifiers(colWhourName);
                whourData = new Object[2];

                try {
                    DoktorDAO doktorDAO = new DoktorDAO();
                    List<DoktorCalismaSaati> whourList = doktorDAO.getListWhourId(Id);
                    for (int i = 0; i < whourList.size(); i++) {

                        whourData[0] = whourList.get(i).getId();

                        whourData[1] = whourList.get(i).getWdate();

                        this.whourModel.addRow(whourData);

                    }

                    h.getTable_calismaSaati().setModel(whourModel);
                    h.getScrlpane_calismaSaati().setViewportView(h.getTable_calismaSaati());
                    h.getTable_calismaSaati().getColumnModel().getColumn(0).setPreferredWidth(5);

                } catch (IOException ex) {
                    Logger.getLogger(HastaGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                Helper.ShowMsg("Lütfen doktor seçiniz...");
            }

        } else if (e.getSource() == h.getBtn_cikis()) {

            GirisGUI g = new GirisGUI();
            g.setVisible(true);
            h.dispose();

        } else if (e.getSource() == h.getBtn_randevuAl()) {

            int selectedRowDoktor = h.getTable_doktorList().getSelectedRow();
            int selectedRowWhour = h.getTable_calismaSaati().getSelectedRow();

            if (selectedRowDoktor >= 0 && selectedRowWhour >= 0) {
                try {
                    String Id = h.getTable_doktorList().getModel().getValueAt(selectedRowDoktor, 0).toString();
                    String doktorName = h.getTable_doktorList().getModel().getValueAt(selectedRowDoktor, 1).toString();
                    int doktorId = Integer.parseInt(Id);

                    String date = h.getTable_calismaSaati().getModel().getValueAt(selectedRowWhour, 1).toString();

                    this.getHy().createRandevu(doktorId, doktorName, h.getH().getId(), h.getH().getName(), date);
                    h.updateRandevuModel();
                    Helper.ShowMsg("Randevu alma işlemi başarılı...");
                } catch (IOException ex) {
                    Logger.getLogger(HastaGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                Helper.ShowMsg("Lütfen doktor ve tarih seçiniz...");
            }

        } else if (e.getSource() == h.getBtn_randevuSil()) {

            String Id = h.getTxtfld_kullaniciId().getText();

            if (Id.length() == 0) {
                Helper.ShowMsg("fill");
            } else {

                try {
                    this.getHy().deleteRandevu(Id);
                    h.updateRandevuModel();
                    h.getTxtfld_kullaniciId().setText(null);
                    Helper.ShowMsg("Randevu silme işlemi başarılı...");

                } catch (IOException ex) {
                    Logger.getLogger(HastaGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else {

        }

    }
}
