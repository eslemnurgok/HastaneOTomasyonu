/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim;

import DAO.*;
import java.io.*;
import java.util.List;
import model.Doktor;
import model.DoktorCalismaSaati;

/**
 *
 * @author Muzaffer
 */
public class DoktorYonetim {

    private Doktor doktor;
    private List<Doktor> liste;
    private DoktorDAO userDatabase;

    public DoktorYonetim() {
    }

    public void create(String tcNo, String sifre, String name) throws IOException {

        Doktor newDoktor = this.getDoktor();

        newDoktor.setTcNo(tcNo);
        newDoktor.setSifre(sifre);
        newDoktor.setName(name);

        this.getUserDatabase().addUser(newDoktor);

    }

    public void addWhour(int Id, String doktorName, String wdate) throws IOException {
        Doktor newDoktor = this.getDoktor();
        newDoktor.setName(doktorName);
        newDoktor.setId(Id);

        DoktorCalismaSaati dcs = new DoktorCalismaSaati();
        dcs.setD(newDoktor);
        dcs.setWdate(wdate);
        this.getUserDatabase().addWhour(dcs);
    }

    public void deleteUser(String Id) throws IOException {

        this.getUserDatabase().deleteUser(Id);

    }

    public void deleteWhour(String Id) throws IOException {

        this.getUserDatabase().deleteWhour(Id);

    }

    public boolean checkUser(String tcNo, String sifre) throws IOException {
        Doktor newDoktor = this.getDoktor();
        newDoktor.setTcNo(tcNo);
        newDoktor.setSifre(sifre);
        return getUserDatabase().checkUser(newDoktor);
    }

    public boolean checkUserK(String tcNo, String sifre) throws IOException {
        Doktor newDoktor = this.getDoktor();
        newDoktor.setTcNo(tcNo);
        newDoktor.setSifre(sifre);
        return getUserDatabase().checkUserK(newDoktor);
    }

    public Doktor returnDoktor(String tcNo, String sifre) throws IOException {
        Doktor newDoktor = new Doktor();
        newDoktor.setTcNo(tcNo);
        newDoktor.setSifre(sifre);
        return getUserDatabase().returnDoktor(newDoktor);
    }

    public Doktor getDoktor() {
        if (this.doktor == null) {
            this.doktor = new Doktor();
        }
        return this.doktor;
    }

    public void setHasta(Doktor doktor) {
        this.doktor = doktor;
    }

    public List<Doktor> getListe() {
        return liste;
    }

    public void setListe(List<Doktor> liste) {
        this.liste = liste;
    }

    public DoktorDAO getUserDatabase() {
        if (this.userDatabase == null) {
            userDatabase = new DoktorDAO();
        }
        return userDatabase;
    }

    public void setUserDatabase(DoktorDAO userDatabase) {
        this.userDatabase = userDatabase;
    }

}
