/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim;

import DAO.*;

import java.io.*;
import java.util.List;
import model.Bashekim;
import model.Doktor;
import model.Poliklinik;

/**
 *
 * @author Muzaffer
 */
public class BashekimYonetim {

    private Bashekim bashekim;
    private Doktor doktor;
    private Poliklinik poliklinik;
    private List<Bashekim> liste;
    private BashekimDAO userDatabase;

    public BashekimYonetim() {
    }

    public Bashekim returnBashekim(String tcNo, String sifre) throws IOException {
        Bashekim newBashekim = this.getBashekim();
        newBashekim.setTcNo(tcNo);
        newBashekim.setSifre(sifre);
        return getUserDatabase().returnBashekim(newBashekim);
    }

    public void addWorker(int doktorId, String doktorName, int polikilinikId, String poliklinikName) throws IOException {

        Doktor newDoktor = this.getDoktor();
        Poliklinik newPoliklinik = this.getPoliklinik();

        newDoktor.setId(doktorId);
        newDoktor.setName(doktorName);

        newPoliklinik.setId(polikilinikId);
        newPoliklinik.setName(poliklinikName);

        this.getUserDatabase().addWorker(newDoktor, newPoliklinik);
    }

    public void createUser(String tcNo, String sifre, String isimSoyisim) throws IOException {

        Bashekim newBashekim = this.getBashekim();

        newBashekim.setTcNo(tcNo);
        newBashekim.setSifre(sifre);
        newBashekim.setName(isimSoyisim);

        this.getUserDatabase().addUser(newBashekim);

    }

    public boolean checkUser(String tcNo, String sifre) throws IOException {
        Bashekim newBashekim = this.getBashekim();
        newBashekim.setTcNo(tcNo);
        newBashekim.setSifre(sifre);
        return getUserDatabase().checkUser(newBashekim);
    }

    public Poliklinik getPoliklinik() {
        if (this.poliklinik == null) {
            this.poliklinik = new Poliklinik();
        }
        return poliklinik;
    }

    public void setPoliklinik(Poliklinik poliklinik) {
        this.poliklinik = poliklinik;
    }

    public Doktor getDoktor() {
        if (this.doktor == null) {
            this.doktor = new Doktor();
        }
        return doktor;
    }

    public void setDoktor(Doktor doktor) {
        this.doktor = doktor;
    }

    public Bashekim getBashekim() {
        if (this.bashekim == null) {
            this.bashekim = new Bashekim();
        }
        return bashekim;
    }

    public void setBashekim(Bashekim bashekim) {
        this.bashekim = bashekim;
    }

    public List<Bashekim> getListe() {
        return liste;
    }

    public void setListe(List<Bashekim> liste) {
        this.liste = liste;
    }

    public BashekimDAO getUserDatabase() {
        if (userDatabase == null) {
            this.userDatabase = new BashekimDAO();
        }
        return userDatabase;
    }

    public void setUserDatabase(BashekimDAO userDatabase) {
        this.userDatabase = userDatabase;
    }

}
