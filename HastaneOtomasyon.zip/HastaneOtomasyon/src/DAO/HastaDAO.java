/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import dosya.*;
import helper.Helper;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import model.Doktor;
import model.Hasta;
import model.Randevu;

/**
 *
 * @author Muzaffer
 */
public class HastaDAO {

    dosyaIslemleri dosya = new dosyaIslemleri();
    private final List<Hasta> hastaList = new ArrayList<>();
    private final List<Randevu> randevuList = new ArrayList<>();

    public HastaDAO() {
    }

    public void addRandevu(Doktor d, Hasta h, String date) {
        dosya.addRandevu(d.getId(), d.getName(), h.getId(), h.getName(), date, "Randevu.txt");
    }
    
    public void delete(String Id)throws IOException{
         dosya.delete("Randevu.txt", Id);
    }

    public void add(Hasta h) throws IOException {
        dosya.add(h, "User.txt");
    }

    public List<Hasta> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\User.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");
            if ("Hasta".equals(parts[4])) {
                Hasta d = new Hasta(Integer.parseInt(parts[0]), parts[1], parts[2], parts[3], parts[4]);

                hastaList.add(d);

            }
            line = bR.readLine();

        }
        return this.hastaList;
    }

    public boolean checkUser(Hasta newHasta) throws IOException {
        List<Hasta> list = this.getList();
        boolean check = false;

        for (Hasta k : list) {
            if (k.equals(newHasta)) {
                Helper.ShowMsg("success");
                check = true;
            }
        }
        return check;
    }

    public boolean checkUserK(Hasta newHasta) throws IOException {
        List<Hasta> list = this.getList();
        boolean check = false;

        for (Hasta k : list) {
            if (k.equals(newHasta)) {

                check = true;
            }
        }
        return check;
    }

    public Hasta returnHasta(Hasta newHasta) throws IOException {
        List<Hasta> list = this.getList();

        for (Hasta k : list) {
            if (k.equals(newHasta)) {

                Hasta h = new Hasta(k.getId(), k.getTcNo(), k.getSifre(), k.getName(), k.getType());

                return h;
            }
        }
        return null;

    }

    public List<Randevu> getListRandevu(int Id) throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\Randevu.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");
            if (String.valueOf(Id).equals(parts[3])) {
                Randevu r = new Randevu(Integer.parseInt(parts[0]), parts[2], parts[4], parts[5]);

                randevuList.add(r);

            }
            line = bR.readLine();

        }
        return this.randevuList;
    }

}
