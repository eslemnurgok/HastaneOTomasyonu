/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import dosya.*;
import helper.*;
import java.io.*;
import java.util.*;
import model.*;

/**
 *
 * @author Muzaffer
 */
public class DoktorDAO {

    private dosyaIslemleri dosya = new dosyaIslemleri();
    private final List<Doktor> doktorList = new ArrayList<>();
    private final List<DoktorCalismaSaati> whourList = new ArrayList<>();
    private final List<DoktorCalismaSaati> whourListId = new ArrayList<>();
    private Doktor doktor;

    public DoktorDAO() {
    }

    public DoktorDAO(Doktor d) {
        this.doktor = d;
    }

    public Doktor getDoktor() {
        return doktor;
    }

    public void setDoktor(Doktor doktor) {
        this.doktor = doktor;
    }

    public void addUser(Doktor d) throws IOException {
        dosya.add(d, "User.txt");
    }

    public void addWhour(DoktorCalismaSaati dcs) throws IOException {
        dosya.add(dcs, "CalismaSaat.txt");
    }

    public List<Doktor> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\User.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");
            if ("Doktor".equals(parts[4])) {
                Doktor d = new Doktor(Integer.parseInt(parts[0]), parts[1], parts[2], parts[3], parts[4]);
                doktorList.add(d);
            }

            line = bR.readLine();
        }
        return this.doktorList;
    }

    public boolean checkUser(Doktor newDoktor) throws IOException {
        List<Doktor> list = this.getList();
        boolean check = false;

        for (Doktor d : list) {
            if (d.equals(newDoktor)) {

                Helper.ShowMsg("success");

                check = true;
            }
        }
        return check;
    }

    public boolean checkUserK(Doktor newDoktor) throws IOException {
        List<Doktor> list = this.getList();
        boolean check = false;

        for (Doktor d : list) {
            if (d.equals(newDoktor)) {

                check = true;
            }
        }
        return check;
    }

    public Doktor returnDoktor(Doktor newDoktor) throws IOException {
        List<Doktor> list = this.getList();

        for (Doktor k : list) {
            if (k.equals(newDoktor)) {

                Doktor d = new Doktor(k.getId(), k.getTcNo(), k.getSifre(), k.getName(), k.getType());

                return d;
            }
        }
        return null;

    }

    public List<DoktorCalismaSaati> getListWhour() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\CalismaSaat.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");

            if (doktor.getName().equals(parts[2])) {
                Doktor d = new Doktor();
                d.setName(parts[2]);
                d.setId(Integer.parseInt(parts[1]));
                DoktorCalismaSaati whour = new DoktorCalismaSaati(Integer.parseInt(parts[0]), d, parts[3]);
                whourList.add(whour);
            }

            line = bR.readLine();
        }
        return this.whourList;
    }

    public List<DoktorCalismaSaati> getListWhourId(int Id) throws IOException {

        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\CalismaSaat.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");
            if (String.valueOf(Id).equals(parts[1])) {
                Doktor d = new Doktor();
                d.setName(parts[2]);
                d.setId(Integer.parseInt(parts[1]));
                DoktorCalismaSaati whour = new DoktorCalismaSaati(Integer.parseInt(parts[0]), d, parts[3]);
                whourListId.add(whour);
            }

            line = bR.readLine();
        }
        return this.whourListId;
    }

    public void deleteUser(String Id) throws IOException {
        dosya.delete("User.txt", Id);
    }

    public void deleteWhour(String Id) throws IOException {
        dosya.delete("CalismaSaat.txt", Id);
    }
}
